<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Booking extends CI_Controller {

	public function __construct()
	{
        parent::__construct();
        
        if(! $this->session->userdata('id_session'))
        {
            redirect('Login');
        }
        $this->load->model('Booking_model');
        
	}


	public function index()
	{
		
		$periode = $this->uri->segment('3');
		$data['kamar'] = $this->Booking_model->typekamar();
		$data['periode'] = $this->Booking_model->periode($periode);
		$data['cal'] = $this->Booking_model->setcalender($periode);

		$this->load->view('header');
		$this->load->view('sidemenu');
		$this->load->view('periode/booking', $data);
		$this->load->view('footer');		
	}


	public function tampilkancalender()
	{
		$period = $this->input->post('period');
		$response = $this->Booking_model->tampilkancalender($period);
		echo json_encode($response);
	}


	public function updateavail()
	{
		$id = $this->input->post('id');;
		$nilai = $this->input->post('nilai');

		$response = $this->Booking_model->updateavail($id, $nilai);
		echo json_encode($response);
	}


	public function updateprice()
	{
		$id = $this->input->post('id');;
		$nilai = $this->input->post('nilai');

		$response = $this->Booking_model->updateprice($id, $nilai);
		echo json_encode($response);
	}

}

/* End of file Booking.php */
/* Location: ./application/controllers/Booking.php */