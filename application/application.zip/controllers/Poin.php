<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Poin extends CI_Controller {


	public function __construct()
	{
		parent::__construct();
		if(! $this->session->userdata('id_session'))
        {
            redirect('Login');
        }
        $this->load->model('Poin_model');
        $this->load->model('Common_model', 'umum');
	}


	public function index()
	{
		
        $data['user'] = $this->umum->getdatauser();

        $this->load->view('header');
		$this->load->view('sidemenu');
		$this->load->view('usermanagement/poinlist', $data);
		$this->load->view('footer');		
	}


	function fetch_datatable()
    {

        $fetch_data = $this->Poin_model->make_datatables();
        $data = array();
        $nomor = 0;
        foreach ($fetch_data as $aRow) 
        {
            $nomor++;
            $row = array();
            $row[] = $nomor;
            $row[] = $aRow->id_user;
            $row[] = $aRow->fullname;
            $row[] = $aRow->poin;
            $row[] = date('d-m-Y H:i:s', strtotime($aRow->tanggal));
            $row[] = $aRow->keterangan;
             
            $row[] = '<center><button onclick="deleteData('.$aRow->id.')" style="width:50px;" class="btn-xs btn-danger">Delete</button></center>';


            
            $data[] = $row;


            
        }

        $output = array(
            "draw"              => intval($_POST["draw"]),
            "recordsTotal"      => $this->Poin_model->get_all_data(),
            "recordsFiltered"   => $this->Poin_model->get_filtered_data(),
            "data"              => $data

        );

        echo json_encode($output);  
    }


    public function savedata()
    {
        
        $id_user = $this->input->post('id_user');
        $jumlah = $this->input->post('jumlah');
        $ket = $this->input->post('keterangan');

        $length = count($id_user);

        for($i=0; $i<$length ; $i++)
        {
            $data_insert = array(
                "id_user" => $id_user[$i],
                "poin" => $jumlah,
                "keterangan" => $ket,
                "tanggal" => date('Y-m-d H:i:s')
            );

            $response = $this->Poin_model->savedata($data_insert);
        }


        echo json_encode($response);

    }



    public function deleteData()
    {
    	$id = $this->input->post('id');
    	$response = $this->Poin_model->deleteData($id);
    	echo json_encode($response);
    }


   

}

/* End of file Users.php */
/* Location: ./application/controllers/Users.php */