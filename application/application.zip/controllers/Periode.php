<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Periode extends CI_Controller {


	public function __construct()
	{
		
        parent::__construct();
        
        if(! $this->session->userdata('id_session'))
        {
            redirect('Login');
        }
        $this->load->model('Periode_model');
        
	}




	public function index()
	{
		
		$data['roomtype'] = $this->Periode_model->roomtype();

		$this->load->view('header');
		$this->load->view('sidemenu');
		$this->load->view('periode/index', $data);
		$this->load->view('footer');		
	}


	function fetch_datatable()
    {

        $fetch_data = $this->Periode_model->make_datatables();
        $data = array();
        $nomor = 0;
        foreach ($fetch_data as $aRow) 
        {
            
            $rtype = explode(",", $aRow->room_type);
            $html = '';
            for($i=0; $i<count($rtype); $i++) 
            {
                
                $html .= '<ul>';
                $this->db->where('id', $rtype[$i]);
                $qry = $this->db->get('jatra_roomtype_table')->result();
                foreach ($qry as $k) {
                    $html .= '<li>'.$k->room_name.'</li>';
                }

                $html .= '</ul>';
            }



            $nomor++;
            $row = array();
            $row[] = $nomor;
            

            if($aRow->periode == '01')
            {
            	$row[] = 'Januari '.$aRow->tahun;
            }
            else if($aRow->periode == '02')
            {
            	$row[] = 'Februari '.$aRow->tahun;
            }
            else if($aRow->periode == '03')
            {
            	$row[] = 'Maret '.$aRow->tahun;
            }
            else if($aRow->periode == '04')
            {
            	$row[] = 'April '.$aRow->tahun;
            }
            else if($aRow->periode == '05')
            {
            	$row[] = 'Mei '.$aRow->tahun;
            }
            else if($aRow->periode == '06')
            {
            	$row[] = 'Juni '.$aRow->tahun;
            }
            else if($aRow->periode == '07')
            {
            	$row[] = 'Juli '.$aRow->tahun;
            }
            else if($aRow->periode == '08')
            {
            	$row[] = 'Agustus '.$aRow->tahun;
            }
            else if($aRow->periode == '09')
            {
            	$row[] = 'September '.$aRow->tahun;
            }
            else if($aRow->periode == '10')
            {
            	$row[] = 'Oktober '.$aRow->tahun;
            }
            else if($aRow->periode == '11')
            {
            	$row[] = 'November '.$aRow->tahun;
            }
            else if($aRow->periode == '12')
            {
            	$row[] = 'Desember '.$aRow->tahun;
            }



            $row[] = $html;

            $row[] = '<center><a href="'.base_url().'index.php/Booking/index/'.$aRow->id.'"><button style="width:100px;margin-right:10px;" class="btn-xs btn-success">Set Data</button></a><button onclick="deleteData('.$aRow->id.')" style="width:50px;" class="btn-xs btn-danger">Delete</button></center>';
            
            $data[] = $row;
            
        }

        $output = array(
            "draw"              => intval($_POST["draw"]),
            "recordsTotal"      => $this->Periode_model->get_all_data(),
            "recordsFiltered"   => $this->Periode_model->get_filtered_data(),
            "data"              => $data

        );

        echo json_encode($output);  
    }




    public function savedata()
    {
        $periode = $this->input->post('periode');
        $tahun = $this->input->post('tahun');
        $type = $this->input->post('roomtype');
        $response = $this->Periode_model->savedata($periode, $tahun, $type);
        echo json_encode($response);

    }


    public function getdatabyid($id) 
    {
    	$data = $this->Periode_model->getdatabyid($id);
    	$response = array(
    		"data" => $data,
    		"message" => 'sukses'
    	);

    	echo json_encode($response);
    }


    public function updateData()
    {
    	$id = $this->input->post('id');

    	$cityname = $this->input->post('cityname');
        $gambar = $this->input->post('gambar');

        

        $nama_icon = $_FILES['gambar']['name'];
        $ext_icon = pathinfo($nama_icon, PATHINFO_EXTENSION);
        $gen_name = uniqid();


        $config['upload_path'] = './assets/images/icon_kota/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '1000';
        $config['file_name'] = $gen_name; 

    
        if(!empty($nama_icon)) 
        {
            $this->load->library('upload', $config);
            if(! $this->upload->do_upload('file')) 
            {
                $response['message'] = 'failed';
            }
            else
            {
                
                $gambarlama = $this->Periode_model->gambarlama($id);
                if(file_exists('./assets/images/icon_kota/'.$gambarlama))
                {
                    unlink('./assets/images/icon_kota/'.$gambarlama);
                }

                $data_upload = $this->upload->data();
                $data_insert = array(
                    "nama_kota" => $cityname,
                    "icon" => $gen_name.".".$ext_icon,
                );

                $res = $this->Periode_model->updatedata($data_insert, $id);
                if($res)
                {
                    $response['message'] = 'sukses';    
                }

            }
        }
        else
        {
            $data_insert = array(
                "nama_kota" => $cityname
            );

            $res = $this->Periode_model->updatedata($data_insert, $id);
            if($res)
            {
                $response['message'] = 'sukses';    
            }
        }

        

        echo json_encode($response);
    }


    public function deleteData()
    {
    	$id = $this->input->post('id');
    	$response = $this->Periode_model->deleteData($id);
    	echo json_encode($response);
    }

}

/* End of file Users.php */
/* Location: ./application/controllers/Users.php */