<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
		$this->load->view('login');		
	}

	public function proseslogin()
	{
		

		$email = $this->input->post('emailjatra');
		$pass = $this->input->post('passwordjatra');

		$data = array(
			"jatra_email" => $email,
			"jatra_password" => SHA1($pass) 
		);

		$this->load->model('Login_model');
		$response = $this->Login_model->proseslogin($data);
		if($response['sukses'] == 'sukses')
		{
			$data_session = array(
				"id_session" => $response['data'][0]->id,
				"email_session" => $response['data'][0]->jatra_email,
				"name_session" => $response['data'][0]->jatra_fullname,
				"phone_session" => $response['data'][0]->telepon,
				"level_session" => $response['data'][0]->level

			);

			$this->session->set_userdata($data_session);
		}
		

		echo json_encode($response);

	}



}

/* End of file Login.php */
/* Location: ./application/controllers/Login.php */