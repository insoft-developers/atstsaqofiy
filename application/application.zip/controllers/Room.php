<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Room extends CI_Controller {


	public function __construct()
	{
		parent::__construct();
		if(! $this->session->userdata('id_session'))
        {
            redirect('Login');
        }
        $this->load->model('Room_model');
        $this->load->model('Common_model', 'umum');
	}


	public function index()
	{
		
        $data['listhotel'] = $this->umum->getdatahotel();
        $data['listtype'] = $this->umum->gettypefasilitas();
        $this->load->view('header');
		$this->load->view('sidemenu');
		$this->load->view('hotelmanagement/roomlist', $data);
		$this->load->view('footer');		
	}


	function fetch_datatable()
    {

        $fetch_data = $this->Room_model->make_datatables();
        $data = array();
        $nomor = 0;
        foreach ($fetch_data as $aRow) 
        {
            $nomor++;
            $row = array();
            $row[] = $nomor;
            $row[] = $aRow->room_name;
            if($aRow->type == 1)
            {
                $row[] = 'Room';
            }
            elseif($aRow->type == 2)
            {
                $row[] = 'Restaurant';
            }
            elseif($aRow->type == 3)
            {
                $row[] = 'Spa';
            }
            elseif($aRow->type == 4)
            {
                $row[] = 'Fitness Centre';
            }
            elseif($aRow->type == 5)
            {
                $row[] = 'Book Transportation';
            }
            $row[] = $aRow->hotel_name.'<br>['.$aRow->kota.']';
            $row[] = $aRow->room_size;
            $row[] = $aRow->room_pax;
            $row[] = $aRow->bedding_option;
            $row[] = 'Rp. '.number_format($aRow->booking_price);
            $row[] = '<center><a href="javascript:void(0);"><p id="room_description" data-id = "'.$aRow->id.'" data-room="'.$aRow->room_name.'" data-hotel="'.$aRow->hotel_name.'" data-kota="'.$aRow->kota.'">Description</p></a></center>';    
            $row[] = '<center><a href="javascript:void(0);"><p id="slide_image" data-id = "'.$aRow->id.'" data-room="'.$aRow->room_name.'" data-hotel="'.$aRow->hotel_name.'" data-kota="'.$aRow->kota.'" data-idhotel="'.$aRow->id_hotel.'">Images</p></a></center>';
            
            $row[] = '<center><button onclick="editData('.$aRow->id.')" style="width:50px;margin-bottom:5px;" class="btn-xs btn-warning">Edit</button><br><button onclick="deleteData('.$aRow->id.')" style="width:50px;" class="btn-xs btn-danger">Delete</button></center>';


            
            $data[] = $row;


            
        }

        $output = array(
            "draw"              => intval($_POST["draw"]),
            "recordsTotal"      => $this->Room_model->get_all_data(),
            "recordsFiltered"   => $this->Room_model->get_filtered_data(),
            "data"              => $data

        );

        echo json_encode($output);  
    }


    public function savedata()
    {
        
        $roomname = $this->input->post('roomname');
        $type = $this->input->post('facetype');
        $hotelname = $this->input->post('hotelname');
        $roomsize = $this->input->post('roomsize');
        $roompax = $this->input->post('roompax');
        $beddingoption = $this->input->post('beddingoption');
        $price = $this->input->post('bookingprice');

        $data_insert = array(
            "id_hotel" => $hotelname,
            "type" => $type,
            "room_name" => $roomname,
            "room_size" => $roomsize,
            "room_pax" => $roompax,
            "bedding_option" => $beddingoption,
            "booking_price" => $price
        );

        $response = $this->Room_model->savedata($data_insert);
        echo json_encode($response);
        
    }


    public function getdatabyid($id) 
    {
    	$data = $this->Room_model->getdatabyid($id);
    	$response = array(
    		"data" => $data,
    		"message" => 'sukses'
    	);

    	echo json_encode($response);
    }


    public function updateData()
    {
    	
        $id = $this->input->post('id');
        $roomname = $this->input->post('roomname');
        $type = $this->input->post('facetype');
        $hotelname = $this->input->post('hotelname');
        $roomsize = $this->input->post('roomsize');
        $roompax = $this->input->post('roompax');
        $beddingoption = $this->input->post('beddingoption');
        $price = $this->input->post('bookingprice');

        $data_update = array(
            "id_hotel" => $hotelname,
            "type" => $type,
            "room_name" => $roomname,
            "room_size" => $roomsize,
            "room_pax" => $roompax,
            "bedding_option" => $beddingoption,
            "booking_price" => $price
        );

        $response = $this->Room_model->updatedata($data_update, $id);
        echo json_encode($response);
    	
    }


    public function deleteData()
    {
    	$id = $this->input->post('id');
    	$response = $this->Room_model->deleteData($id);
    	echo json_encode($response);
    }


    public function updatedescription()
    {
        $id = $this->input->post('id_room_desc');
        $roomtitle = $this->input->post('roomtitle');
        $roomsubtitle = $this->input->post('roomsubtitle');
        $roomdescription = $this->input->post('roomdescription');
        $facilitiesdescription = $this->input->post('fasilitiesdescription');


        $data_update = array(
            "room_title" => $roomtitle,
            "room_subtitle" => $roomsubtitle,
            "room_description" => $roomdescription,
            "facilities_description" => $facilitiesdescription
        );


        $response = $this->Room_model->updatedescription($data_update, $id); 
        echo json_encode($response);

    }


    public function getdescriptiondata($id)
    {
        $response = $this->Room_model->getdescriptiondata($id);
        echo json_encode($response);
    }



    public function slider($id)
    {
        
        $HTML = "";
        $HTML .= "<table class='table table-stripped table-bordered' id='table-hotel-slider'>";
        $HTML .= "<thead>";
        $HTML .= "<tr>";
        $HTML .= "<th width='10%'>ID</th>";
        $HTML .= "<th width='*'>Image</th>";
        $HTML .= "<th width='10%'>Action</th>";
        $HTML .= "</tr>";
        $HTML .= "</thead>";
        $HTML .= "<tbody>";

        $list_hotel_slider = $this->Room_model->list_room_slider($id);
        if($list_hotel_slider->num_rows() > 0)
        {
            foreach ($list_hotel_slider->result() as $key ) {
                $HTML .= "<tr>";
                $HTML .= "<td>".$key->id."</td>";
                $HTML .= "<td><img style='width:80px; height:70px;' src='".base_url()."assets/images/room_slider/".$key->image."' /></td>";
                $HTML .= "<td><button onclick='deleteSlider(".$key->id.", ".$key->id_room.")' type='button' class='btn btn-danger btn-sm'>Delete</button></td>";
                $HTML .= "</tr>";
            }
        }
        else
        {
            $HTML .= "<tr>";
            $HTML .= "<td colspan='3'><center>No Image List</center></td>";
            $HTML .= "</tr>";
        }
        



        $HTML .= "</tbody>";
        $HTML .= "</table>";

        echo json_encode($HTML);
    }


    public function saveslider()
    {
        $id_kamar = $this->input->post('id_kamar');
        $id_hotel = $this->input->post('id_hotel');
        $slider = $this->input->post('_slider');

        $nama_icon = $_FILES['_slider']['name'];
        $ext_icon = pathinfo($nama_icon, PATHINFO_EXTENSION);
        $gen_name = uniqid();


        $config['upload_path'] = './assets/images/room_slider/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '1000';
        $config['file_name'] = $gen_name; 

        

        $this->load->library('upload', $config);
        if(! $this->upload->do_upload('file')) 
        {
            $response['message'] = 'failed';
        }
        else
        {
            
            $data_upload = $this->upload->data();
            $data_insert = array(
                "id_room" => $id_kamar,
                "id_hotel" => $id_hotel,
                "image" => $gen_name.".".$ext_icon,
            );

            $res = $this->Room_model->saveslider($data_insert);
            if($res)
            {
                $response['message'] = 'sukses';    
            }

        }

        echo json_encode($response);

    }


    public function hapusimageslider()
    {
        $id = $this->input->post('id');
        $response = $this->Room_model->hapusimageslider($id);
        echo json_encode($response);
    }

}

/* End of file Users.php */
/* Location: ./application/controllers/Users.php */