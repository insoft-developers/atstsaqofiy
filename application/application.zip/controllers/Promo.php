<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Promo extends CI_Controller {


	public function __construct()
	{
		parent::__construct();
		if(! $this->session->userdata('id_session'))
        {
            redirect('Login');
        }
        $this->load->model('Promo_model');
        $this->load->model('Common_model', 'umum');
	}


	public function index()
	{
		
        $data['hotel'] = $this->umum->getdatahotel();

        $this->load->view('header');
		$this->load->view('sidemenu');
		$this->load->view('promomanagement/promolist', $data);
		$this->load->view('footer');		
	}


	function fetch_datatable()
    {

        $fetch_data = $this->Promo_model->make_datatables();
        $data = array();
        $nomor = 0;
        foreach ($fetch_data as $aRow) 
        {
            $nomor++;
            $row = array();
            $row[] = $nomor;
            $row[] = $aRow->judul_promo;
            $row[] = $aRow->nama_hotel. '-' .$aRow->kota;
            $row[] = '<img style="width:200px;height:140px;" src="'.base_url().'assets/images/promo/'.$aRow->gambar.'"/>';    
            if($aRow->status == '1')
            {
                $row[] = 'aktif';
            }  
            else
            {
                $row[] = 'nonaktif';
            }

            $row[] = date('d-m-Y', strtotime($aRow->expired_date));
            $row[] = date('d-m-Y H:i:s', strtotime($aRow->created_at));
            
            $row[] = '<center><button onclick="editData('.$aRow->id.')" style="width:50px;margin-bottom:5px;" class="btn-xs btn-warning">Edit</button><br><button onclick="deleteData('.$aRow->id.')" style="width:50px;" class="btn-xs btn-danger">Delete</button></center>';


            
            $data[] = $row;


            
        }

        $output = array(
            "draw"              => intval($_POST["draw"]),
            "recordsTotal"      => $this->Promo_model->get_all_data(),
            "recordsFiltered"   => $this->Promo_model->get_filtered_data(),
            "data"              => $data

        );

        echo json_encode($output);  
    }


    public function savedata()
    {
        $promoname = $this->input->post('promoname');
        $hotelname = $this->input->post('hotelname');
        $expired = $this->input->post('expireddate');
        $gambar = $this->input->post('gambar');
        $status = $this->input->post('promostatus');
        $deskripsi = $this->input->post('promodescription');

        $nama_icon = $_FILES['gambar']['name'];
        $ext_icon = pathinfo($nama_icon, PATHINFO_EXTENSION);
        $gen_name = uniqid();


        $config['upload_path'] = './assets/images/promo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '1000';
        $config['file_name'] = $gen_name; 

        

        $this->load->library('upload', $config);
        if(! $this->upload->do_upload('file')) 
        {
            $response['message'] = 'failed';
        }
        else
        {
            
            $data_upload = $this->upload->data();
            $data_insert = array(
                "judul_promo" => $promoname,
                "id_hotel" => $hotelname,
                "gambar" => $gen_name.".".$ext_icon,
                "deskripsi" => $deskripsi,
                "status" => $status,
                "expired_date" => $expired,
                "created_at" => date('Y-m-d H:i:s')
             );

            $res = $this->Promo_model->savedata($data_insert);
            if($res)
            {
                $response['message'] = 'sukses';    
            }

        }

        echo json_encode($response);

    }


    public function getdatabyid($id) 
    {
    	$data = $this->Promo_model->getdatabyid($id);
    	$response = array(
    		"data" => $data,
    		"message" => 'sukses'
    	);

    	echo json_encode($response);
    }


    public function updateData()
    {
    	$id = $this->input->post('id');

    	$promoname = $this->input->post('promoname');
        $hotelname = $this->input->post('hotelname');
        $expired = $this->input->post('expireddate');
        $gambar = $this->input->post('gambar');
        $status = $this->input->post('promostatus');
        $deskripsi = $this->input->post('promodescription');

        

        $nama_icon = $_FILES['gambar']['name'];
        $ext_icon = pathinfo($nama_icon, PATHINFO_EXTENSION);
        $gen_name = uniqid();


        $config['upload_path'] = './assets/images/promo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '1000';
        $config['file_name'] = $gen_name; 

    
        if(!empty($nama_icon)) 
        {
            $this->load->library('upload', $config);
            if(! $this->upload->do_upload('file')) 
            {
                $response['message'] = 'failed';
            }
            else
            {
                
                $gambarlama = $this->Promo_model->gambarlama($id);
                if(file_exists('./assets/images/promo/'.$gambarlama))
                {
                    unlink('./assets/images/promo/'.$gambarlama);
                }

                $data_upload = $this->upload->data();
                $data_insert = array(
                   "judul_promo" => $promoname,
                    "id_hotel" => $hotelname,
                    "gambar" => $gen_name.".".$ext_icon,
                    "deskripsi" => $deskripsi,
                    "status" => $status,
                    "expired_date" => $expired
                );

                $res = $this->Promo_model->updatedata($data_insert, $id);
                if($res)
                {
                    $response['message'] = 'sukses';    
                }

            }
        }
        else
        {
            $data_insert = array(
               "judul_promo" => $promoname,
                "id_hotel" => $hotelname,
                "deskripsi" => $deskripsi,
                "status" => $status,
                "expired_date" => $expired
            );

            $res = $this->Promo_model->updatedata($data_insert, $id);
            if($res)
            {
                $response['message'] = 'sukses';    
            }
        }

        

        echo json_encode($response);
    }


    public function deleteData()
    {
    	$id = $this->input->post('id');
    	$response = $this->Promo_model->deleteData($id);
    	echo json_encode($response);
    }


    public function slider($id)
    {
        
        $HTML = "";
        $HTML .= "<table class='table table-stripped table-bordered' id='table-hotel-slider'>";
        $HTML .= "<thead>";
        $HTML .= "<tr>";
        $HTML .= "<th width='10%'>ID</th>";
        $HTML .= "<th width='*'>Image</th>";
        $HTML .= "<th width='10%'>Action</th>";
        $HTML .= "</tr>";
        $HTML .= "</thead>";
        $HTML .= "<tbody>";

        $list_hotel_slider = $this->Promo_model->list_hotel_slider($id);
        if($list_hotel_slider->num_rows() > 0)
        {
            foreach ($list_hotel_slider->result() as $key ) {
                $HTML .= "<tr>";
                $HTML .= "<td>".$key->id."</td>";
                $HTML .= "<td><img style='width:80px; height:70px;' src='".base_url()."assets/images/hotel_slider/".$key->image."' /></td>";
                $HTML .= "<td><button onclick='deleteSlider(".$key->id.", ".$key->id_hotel.")' type='button' class='btn btn-danger btn-sm'>Delete</button></td>";
                $HTML .= "</tr>";
            }
        }
        else
        {
            $HTML .= "<tr>";
            $HTML .= "<td colspan='3'><center>No Image List</center></td>";
            $HTML .= "</tr>";
        }
        



        $HTML .= "</tbody>";
        $HTML .= "</table>";

        echo json_encode($HTML);
    }


    public function saveslider()
    {
        $id_hotel = $this->input->post('id_hotel');
        $slider = $this->input->post('_slider');

        $nama_icon = $_FILES['_slider']['name'];
        $ext_icon = pathinfo($nama_icon, PATHINFO_EXTENSION);
        $gen_name = uniqid();


        $config['upload_path'] = './assets/images/hotel_slider/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '1000';
        $config['file_name'] = $gen_name; 

        

        $this->load->library('upload', $config);
        if(! $this->upload->do_upload('file')) 
        {
            $response['message'] = 'failed';
        }
        else
        {
            
            $data_upload = $this->upload->data();
            $data_insert = array(
                "id_hotel" => $id_hotel,
                "image" => $gen_name.".".$ext_icon,
            );

            $res = $this->Promo_model->saveslider($data_insert);
            if($res)
            {
                $response['message'] = 'sukses';    
            }

        }

        echo json_encode($response);

    }


    public function hapusimageslider()
    {
        $id = $this->input->post('id');
        $response = $this->Promo_model->hapusimageslider($id);
        echo json_encode($response);
    }

}

/* End of file Users.php */
/* Location: ./application/controllers/Users.php */