<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class City extends CI_Controller {


	public function __construct()
	{
		
        parent::__construct();
        
        if(! $this->session->userdata('id_session'))
        {
            redirect('Login');
        }
        $this->load->model('City_model');
        
	}


	public function index()
	{
		$this->load->view('header');
		$this->load->view('sidemenu');
		$this->load->view('hotelmanagement/citylist');
		$this->load->view('footer');		
	}


	function fetch_datatable()
    {

        $fetch_data = $this->City_model->make_datatables();
        $data = array();
        $nomor = 0;
        foreach ($fetch_data as $aRow) 
        {
            $nomor++;
            $row = array();
            $row[] = $nomor;
            $row[] = $aRow->nama_kota;
            if(!empty($aRow->icon))
            {
                
                $row[] = '<img style="width:40px;height:40px;" src="'.base_url().'assets/images/icon_kota/'.$aRow->icon.'"/>';    
            }
            else
            {
                $row[] = '<img style="width:40px;height:40px;" src="'.base_url().'assets/images/icon_kota/default_icon.jpg"/>';
            }

            
            $row[] = '<center><button onclick="editData('.$aRow->id.')" style="width:50px;margin-right:5px;" class="btn-xs btn-warning">Edit</button><button onclick="deleteData('.$aRow->id.')" style="width:50px;" class="btn-xs btn-danger">Delete</button></center>';
            
            $data[] = $row;


            
        }

        $output = array(
            "draw"              => intval($_POST["draw"]),
            "recordsTotal"      => $this->City_model->get_all_data(),
            "recordsFiltered"   => $this->City_model->get_filtered_data(),
            "data"              => $data

        );

        echo json_encode($output);  
    }


    public function savedata()
    {
        $cityname = $this->input->post('cityname');
        $gambar = $this->input->post('gambar');

        $nama_icon = $_FILES['gambar']['name'];
        $ext_icon = pathinfo($nama_icon, PATHINFO_EXTENSION);
        $gen_name = uniqid();


        $config['upload_path'] = './assets/images/icon_kota/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '1000';
        $config['file_name'] = $gen_name; 

        

        $this->load->library('upload', $config);
        if(! $this->upload->do_upload('file')) 
        {
            $response['message'] = 'failed';
        }
        else
        {
            
            $data_upload = $this->upload->data();
            $data_insert = array(
                "nama_kota" => $cityname,
                "icon" => $gen_name.".".$ext_icon,
            );

            $res = $this->City_model->savedata($data_insert);
            if($res)
            {
                $response['message'] = 'sukses';    
            }

        }

        echo json_encode($response);

    }


    public function getdatabyid($id) 
    {
    	$data = $this->City_model->getdatabyid($id);
    	$response = array(
    		"data" => $data,
    		"message" => 'sukses'
    	);

    	echo json_encode($response);
    }


    public function updateData()
    {
    	$id = $this->input->post('id');

    	$cityname = $this->input->post('cityname');
        $gambar = $this->input->post('gambar');

        

        $nama_icon = $_FILES['gambar']['name'];
        $ext_icon = pathinfo($nama_icon, PATHINFO_EXTENSION);
        $gen_name = uniqid();


        $config['upload_path'] = './assets/images/icon_kota/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '1000';
        $config['file_name'] = $gen_name; 

    
        if(!empty($nama_icon)) 
        {
            $this->load->library('upload', $config);
            if(! $this->upload->do_upload('file')) 
            {
                $response['message'] = 'failed';
            }
            else
            {
                
                $gambarlama = $this->City_model->gambarlama($id);
                if(file_exists('./assets/images/icon_kota/'.$gambarlama))
                {
                    unlink('./assets/images/icon_kota/'.$gambarlama);
                }

                $data_upload = $this->upload->data();
                $data_insert = array(
                    "nama_kota" => $cityname,
                    "icon" => $gen_name.".".$ext_icon,
                );

                $res = $this->City_model->updatedata($data_insert, $id);
                if($res)
                {
                    $response['message'] = 'sukses';    
                }

            }
        }
        else
        {
            $data_insert = array(
                "nama_kota" => $cityname
            );

            $res = $this->City_model->updatedata($data_insert, $id);
            if($res)
            {
                $response['message'] = 'sukses';    
            }
        }

        

        echo json_encode($response);
    }


    public function deleteData()
    {
    	$id = $this->input->post('id');
    	$response = $this->City_model->deleteData($id);
    	echo json_encode($response);
    }

}

/* End of file Users.php */
/* Location: ./application/controllers/Users.php */