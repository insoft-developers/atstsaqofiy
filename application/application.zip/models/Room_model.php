<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Room_model extends CI_Model {

	var $table ="jatra_room_table a";
    var $join = "jatra_hotel_table b";
    var $select_column = array("a.id", "a.room_name","a.type", "b.nama_hotel as hotel_name", "a.room_size", "a.room_pax", "a.bedding_option", "a.booking_price", "b.kota", "a.id_hotel");
    var $order_column = array("a.id", "a.room_name","a.type", "b.nama_hotel", "a.room_size", "a.room_pax", "a.bedding_option", "a.booking_price");


    function make_query()
    {
        $this->db->select($this->select_column);
        $this->db->from($this->table);
        $this->db->join($this->join, "a.id_hotel = b.id");

        if(isset($_POST["search"]["value"]))
        {
            $this->db->like("a.room_name", $_POST["search"]["value"]);
            $this->db->or_like("b.nama_hotel", $_POST["search"]["value"]);
        }

        if(isset($_POST["order"]))
        {
            $this->db->order_by($this->order_column[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }
        else
        {
            $this->db->order_by("a.id","DESC");
        }

    }


    function make_datatables()
    {
        $this->make_query();
        if($_POST["length"] != -1)
        {
            $this->db->limit($_POST["length"], $_POST["start"]);
        }
        $query = $this->db->get();
        return $query->result();
    }


    function get_filtered_data()
    {
        $this->make_query();
        $query = $this->db->get();
        return $query->num_rows();
    }


    function get_all_data()
    {
        $this->db->select("*");
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }



    public function savedata($data)
    {
        $query = $this->db->insert('jatra_room_table', $data);
        return $query;
    }



    public function getdatabyid($id) 
    {
    	$this->db->where('id', $id);
    	$query = $this->db->get('jatra_room_table');
    	return $query->result();
    }


    public function updatedata($data, $id)
    {
    	$this->db->where('id', $id);
        $query = $this->db->update('jatra_room_table', $data);

        return $query;
    }


    public function deleteData($id)
    {
    	
        $this->db->where('id', $id);
    	$query = $this->db->delete('jatra_room_table');
        return $query;
    }




    // API
	public function register($data) 
	{
		$query = $this->db->insert("jatra_user_table", $data);
		return $query;
	}

	public function login($username, $password)
	{
		$this->db->where('username', $username);
		$this->db->where('password', $password);
		$this->db->where('status', 1);
		$query = $this->db->get('jatra_user_table');
		if($query->num_rows()==1)
		{
			$data['data'] = $query->result();
			$data['status'] = true;
			return $data;
		}
		else
		{
			$data['data'] = [];
			$data['status'] = false;
			return $data;
		}
	}


    public function list_hotel_slider($id)
    {
        $this->db->where('id_hotel', $id);
        $this->db->order_by('id', 'desc');
        $query = $this->db->get('jatra_hotel_image_table');
        return $query;
    }


    public function list_room_slider($id)
    {
        $this->db->where('id_room', $id);
        $this->db->order_by('id', 'desc');
        $query = $this->db->get('jatra_room_image_table');
        return $query;
    }


    public function saveslider($data)
    {
        $query = $this->db->insert('jatra_room_image_table', $data);
        return $query;
    }


    public function hapusimageslider($id)
    {
        $this->db->where('id', $id);
        $q = $this->db->get('jatra_room_image_table')->result();
        $file_gambar = $q[0]->image;


        $this->db->where('id', $id);
        $query = $this->db->delete('jatra_room_image_table');
        if($query)
        {
            if(file_exists('./assets/images/room_slider/'.$file_gambar))
            {
                unlink('./assets/images/room_slider/'.$file_gambar);
            }
        }

        return $query;
    }


    public function updatedescription($data, $id)
    {
        $this->db->where('id', $id);
        $query = $this->db->update('jatra_room_table', $data);
        return $query;
    }


    public function getdescriptiondata($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('jatra_room_table');
        return $query->result();
    }


    // API 

    public function facilitylist($id, $id_hotel, $type)
    {
        
        if(!empty($id))
        {
            $this->db->where('id', $id);
        }

        if(!empty($id_hotel))
        {
            $this->db->where('id_hotel', $id_hotel);
        }

        if(!empty($type))
        {
            $this->db->where('type', $type);
        }


        $this->db->select('id as id_fasilitas, id_hotel, type, room_name, room_subtitle , room_title, room_description, room_size, room_pax, bedding_option, facilities_description, booking_price, rating, advisor, location, min_price, max_price, price_range_subtitle, faci_model, faci_model_subtitle');
        $this->db->from('jatra_room_table');
        $query = $this->db->get('');

        $data = array();
        foreach ($query->result() as $key) {

            $url_gambar = base_url().'assets/images/room_slider/';
            $this->db->select('id, id_room as id_fasilitas, id_hotel, CONCAT("'.$url_gambar.'", image) AS gambar', FALSE);
            $this->db->where("id_room", $key->id_fasilitas);
            $query_image = $this->db->get("jatra_room_image_table");

            $row["id_fasilitas"] = $key->id_fasilitas;
            $row["id_hotel"] = $key->id_hotel;
            $row["type"] = $key->type;
            $row["nama_fasilitas"] = $key->room_name;
            $row["subtitle"] = $key->room_subtitle;
            $row["title"] = $key->room_title;
            $row["deskripsi"] = $key->room_description;
            $row["size"] = $key->room_size;
            $row["rating"] = $key->rating;
            $row["advisor"] = $key->advisor;
            $row['location'] = $key->location;
            $row['min_price'] = $key->min_price;
            $row['max_price'] = $key->max_price;
            $row['price_range_subtitle'] = $key->price_range_subtitle;
            $row['faci_model'] = $key->faci_model;
            $row['faci_model_subtitle'] = $key->faci_model_subtitle;
            

            $row["pax"] = $key->room_pax;
            $row["bedding_option"] = $key->bedding_option;
            $row["detail"] = $key->facilities_description;
            $row["booking_price"] = $key->booking_price;
            $row["slider_image"] = $query_image->result();
            array_push($data, $row);
        }


        return $data;

        // return $query->result();
    }






	

}

/* End of file User_model.php */
/* Location: ./application/models/User_model.php */