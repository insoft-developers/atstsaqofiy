<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Booking_model extends CI_Model {

	public function periode($periode)
	{
		$this->db->where('id', $periode);
		$query = $this->db->get('jatra_periode_table');
		return $query->result();
	}


	public function setcalender($periode)
	{
		$this->db->where('id_periode', $periode);
		$query = $this->db->get('jatra_book_table');
		return $query->result();
	}


	public function typekamar()
	{
		$query = $this->db->get('jatra_roomtype_table');
		return $query->result();
	}


	public function tampilkancalender($period)
	{
		
		$kamar = $this->typekamar();

		$HTML = '';
        
        foreach ($kamar as $kmr) { 
        $this->db->where('id_periode', $period);
        $this->db->where('room_type', $kmr->id);
        $cekquery = $this->db->get('jatra_book_table'); 
        if($cekquery->num_rows() > 0){
        $HTML .= '<div class="table table-responsive">';
        $HTML .= '<h5 style="background-color: beige;padding: 14px;">'.$kmr->room_name.'</h5>';
        $HTML .= '<table id="table_calender_<?= $kmr->id ;" class="table table-bordered table-striped nowrap">';
        $HTML .= '<thead><tr><th style="background-color: green;color: white;"></th>';
        
        $cal = $this->setcalender($period);
        foreach ($cal as $key) {  
        if($kmr->id == $key->room_type){
        $namahari = date('D', strtotime($key->tanggal));
        if($namahari == 'Sun'){
        $HTML .= '<th style="text-align: center; background-color:red; color:white;"><small>'.$namahari.'</small><br>'.date('d', strtotime($key->tanggal)).'</th>';}else{
        $HTML .= '<th style="text-align: center;"><small>'.$namahari.'</small><br>'.date('d', strtotime($key->tanggal)).'</th>';}}}
        $HTML .= '</tr><tr><td>Availability</td>';
        foreach ($cal as $key) {  
        if($kmr->id == $key->room_type){
        $HTML .= '<td ondblclick="availdata('.$key->id.')"><span id="avail_id_'.$key->id.'">'.$key->available.'</span><input style="width:40px;display:none;" type="text" id="avail_input_'.$key->id.'"></td>';}} 
        $HTML .= '</tr><tr><td>Price</td>';
        foreach ($cal as $key) {  
        if($kmr->id == $key->room_type){
        $HTML .= '<td ondblclick="pricedata('.$key->id.')"><span id="price_id_'.$key->id.'">'.$key->price.'</span><input style="width:40px;display:none;" type="text" id="price_input_'.$key->id.'"></td>';}} 
        $HTML .= '</tr></thead><tbody></tbody></table></div><br>';}}

        return $HTML;
	}


	public function updateavail($id, $nilai)
	{
		$this->db->where('id', $id);
		$query = $this->db->update('jatra_book_table', array('available'=> $nilai));
		return $query;
	}


	public function updateprice($id, $nilai)
	{
		$this->db->where('id', $id);
		$query = $this->db->update('jatra_book_table', array('price'=> $nilai));
		return $query;
	}
}

/* End of file Booking_model.php */
/* Location: ./application/models/Booking_model.php */