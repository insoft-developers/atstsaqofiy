<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Voucher_model extends CI_Model {

	
    var $table ="jatra_voucher_table v";
    var $join_type = "jatra_type_table t";
    var $join_hotel = "jatra_hotel_table h";
    var $join_fasilitas = "jatra_room_table f";
    var $select_column = array(
        "v.id",
        "v.nama_voucher",
        "v.gambar",
        "t.jenis_fasilitas",
        "h.nama_hotel",
        "f.room_name",
        "v.expired_date",
        "v.voucher_value",
        "v.created_at",
        "v.status",
        "h.kota",
    );
    var $order_column = array(
        "v.id",
        "v.nama_voucher",
        "v.gambar",
        "t.jenis_fasilitas",
        "h.nama_hotel",
        "f.room_name",
        "v.expired_date",
        "v.voucher_value",
        "v.created_at",
        "v.status"
    );

    function make_query()
    {
        $this->db->select($this->select_column);
        $this->db->from($this->table);
        $this->db->join($this->join_type, 'v.type_voucher = t.id');
        $this->db->join($this->join_hotel, 'v.id_hotel = h.id');
        $this->db->join($this->join_fasilitas, 'v.id_fasilitas = f.id');

        if(isset($_POST["search"]["value"]))
        {
            $this->db->like("v.nama_voucher", $_POST["search"]["value"]);
            $this->db->or_like("h.nama_hotel", $_POST["search"]["value"]);
            $this->db->or_like("f.room_name", $_POST["search"]["value"]);
        }

        if(isset($_POST["order"]))
        {
            $this->db->order_by($this->order_column[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }
        else
        {
            $this->db->order_by("v.id","DESC");
        }

    }

    function make_datatables()
    {
        $this->make_query();
        if($_POST["length"] != -1)
        {
            $this->db->limit($_POST["length"], $_POST["start"]);
        }
        $query = $this->db->get();
        return $query->result();
    }


    function get_filtered_data()
    {
        $this->make_query();
        $query = $this->db->get();
        return $query->num_rows();
    }


    function get_all_data()
    {
        $this->db->select("*");
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }






    public function savedata($data)
    {
        $query = $this->db->insert('jatra_voucher_table', $data);
        return $query;
    }



    public function getdatabyid($id) 
    {
    	$this->db->where('id', $id);
    	$query = $this->db->get('jatra_voucher_table');
    	return $query->result();
    }


    public function updateData($data, $id)
    {
    	$this->db->where('id', $id);
        $query = $this->db->update('jatra_voucher_table', $data);

        return $query;
    }


    public function deleteData($id)
    {
    	$this->db->where('id', $id);
        $q = $this->db->get('jatra_voucher_table')->result();
        $file_gambar = $q[0]->gambar;


        $this->db->where('id', $id);
    	$query = $this->db->delete('jatra_voucher_table');
        if($query)
        {
            if(file_exists('./assets/images/voucher/'.$file_gambar))
            {
                unlink('./assets/images/voucher/'.$file_gambar);
            }
        }

        return $query;
    }


    public function gambarlama($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('jatra_voucher_table')->result();
        return $query[0]->gambar;
    }



    // API

    public function voucherlist($id_voucher, $tipe_voucher, $id_hotel, $id_fasilitas)
    {
        if(!empty($id_voucher))
        {
            $this->db->where('id', $id_voucher);
        }
        if(!empty($tipe_voucher))
        {
            $this->db->where('type_voucher', $tipe_voucher);
        }
        if(!empty($id_voucher))
        {
            $this->db->where('id_hotel', $id_hotel);
        }
        if(!empty($id_fasilitas))
        {
            $this->db->where('id_fasilitas', $id_fasilitas);
        }

        $url_gambar = base_url().'assets/images/voucher/';
        $this->db->select('a.id, a.nama_voucher, a.type_voucher, a.id_hotel, a.id_fasilitas, a.start_date, a.expired_date, a.voucher_value, a.created_at, a.status, a.deskripsi, a.avail_status, b.nama_hotel, b.kota as kota_hotel, discount_persen, CONCAT("'.$url_gambar.'", a.gambar) AS gambar_voucher', FALSE);

        $this->db->from('jatra_voucher_table a');
        $this->db->join('jatra_hotel_table b', 'a.id_hotel = b.id');

        $query = $this->db->get('');

        return $query->result();

    }



	

}

/* End of file User_model.php */
/* Location: ./application/models/User_model.php */