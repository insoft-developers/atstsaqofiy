<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class City_model extends CI_Model {

	var $table ="jatra_city_table";
    var $select_column = array("id", "nama_kota", "icon");
    var $order_column = array("id", "nama_kota", "icon");


    function make_query()
    {
        $this->db->select($this->select_column);
        $this->db->from($this->table);

        if(isset($_POST["search"]["value"]))
        {
            $this->db->like("nama_kota", $_POST["search"]["value"]);
        }

        if(isset($_POST["order"]))
        {
            $this->db->order_by($this->order_column[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }
        else
        {
            $this->db->order_by("id","DESC");
        }

    }


    function make_datatables()
    {
        $this->make_query();
        if($_POST["length"] != -1)
        {
            $this->db->limit($_POST["length"], $_POST["start"]);
        }
        $query = $this->db->get();
        return $query->result();
    }


    function get_filtered_data()
    {
        $this->make_query();
        $query = $this->db->get();
        return $query->num_rows();
    }


    function get_all_data()
    {
        $this->db->select("*");
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }



    public function savedata($data)
    {
        $query = $this->db->insert('jatra_city_table', $data);
        return $query;
    }



    public function getdatabyid($id) 
    {
    	$this->db->where('id', $id);
    	$query = $this->db->get('jatra_city_table');
    	return $query->result();
    }


    public function updateData($data, $id)
    {
    	$this->db->where('id', $id);
        $query = $this->db->update('jatra_city_table', $data);

        return $query;
    }


    public function deleteData($id)
    {
    	$this->db->where('id', $id);
        $q = $this->db->get('jatra_city_table')->result();
        $file_gambar = $q[0]->icon;


        $this->db->where('id', $id);
    	$query = $this->db->delete('jatra_city_table');
        if($query)
        {
            if(file_exists('./assets/images/icon_kota/'.$file_gambar))
            {
                unlink('./assets/images/icon_kota/'.$file_gambar);
            }
        }

        return $query;
    }


    public function gambarlama($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('jatra_city_table')->result();
        return $query[0]->icon;
    }


    // API
	public function register($data) 
	{
		$query = $this->db->insert("jatra_user_table", $data);
		return $query;
	}

	public function login($username, $password)
	{
		$this->db->where('username', $username);
		$this->db->where('password', $password);
		$this->db->where('status', 1);
		$query = $this->db->get('jatra_user_table');
		if($query->num_rows()==1)
		{
			$data['data'] = $query->result();
			$data['status'] = true;
			return $data;
		}
		else
		{
			$data['data'] = [];
			$data['status'] = false;
			return $data;
		}
	}



    // API 


    public function citylist()
    {
        
        $url_gambar = base_url().'assets/images/icon_kota/';
        $this->db->select('id, nama_kota, CONCAT("'.$url_gambar.'", icon) AS icon_kota', FALSE);
        $query = $this->db->get('jatra_city_table');
        return $query->result();
    }
	

}

/* End of file User_model.php */
/* Location: ./application/models/User_model.php */