<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Periode_model extends CI_Model {

	var $table ="jatra_periode_table";
    var $select_column = array("id", "periode", "tahun", "room_type");
    var $order_column = array("id", "periode", "tahun", null, null);


    function make_query()
    {
        $this->db->select($this->select_column);
        $this->db->from($this->table);

        if(isset($_POST["search"]["value"]))
        {
            $this->db->like("periode", $_POST["search"]["value"]);
        }

        if(isset($_POST["order"]))
        {
            $this->db->order_by($this->order_column[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }
        else
        {
            $this->db->order_by("id","DESC");
        }

    }


    function make_datatables()
    {
        $this->make_query();
        if($_POST["length"] != -1)
        {
            $this->db->limit($_POST["length"], $_POST["start"]);
        }
        $query = $this->db->get();
        return $query->result();
    }


    function get_filtered_data()
    {
        $this->make_query();
        $query = $this->db->get();
        return $query->num_rows();
    }


    function get_all_data()
    {
        $this->db->select("*");
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }



    public function savedata($periode, $tahun, $type)
    {
        
        $strtype = implode(",", $type);

        $jumlahtype = count($type);



        $data = array(
            "periode" => $periode,
            "tahun" => $tahun,
            "room_type" => $strtype
        );
        
        $query = $this->db->insert('jatra_periode_table', $data);
        $id_periode = $this->db->insert_id();
        if($query)
        {
            
            for($a=0; $a < $jumlahtype; $a++)
            {


                $jumlah_hari = cal_days_in_month(CAL_GREGORIAN, $periode, $tahun);
                for($i=1; $i<$jumlah_hari+1;$i++)
                {
                    
                    $date = $tahun.'-'.$periode.'-'.$i;
                    $insert = array(
                        "id_periode" => $id_periode,
                        "tanggal" => $date,
                        "available" =>0,
                        "price" => 0,
                        "room_type" => $type[$a]

                    );

                    $this->db->insert('jatra_book_table', $insert);
                }
            }    

            
        }
        return $query;
    }



    public function getdatabyid($id) 
    {
    	$this->db->where('id', $id);
    	$query = $this->db->get('jatra_city_table');
    	return $query->result();
    }


    public function updateData($data, $id)
    {
    	$this->db->where('id', $id);
        $query = $this->db->update('jatra_city_table', $data);

        return $query;
    }


    public function deleteData($id)
    {
    	

        $this->db->where('id', $id);
    	$query = $this->db->delete('jatra_periode_table');
        return $query;
    }


    public function gambarlama($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('jatra_city_table')->result();
        return $query[0]->icon;
    }


    // API
	public function register($data) 
	{
		$query = $this->db->insert("jatra_user_table", $data);
		return $query;
	}

	public function login($username, $password)
	{
		$this->db->where('username', $username);
		$this->db->where('password', $password);
		$this->db->where('status', 1);
		$query = $this->db->get('jatra_user_table');
		if($query->num_rows()==1)
		{
			$data['data'] = $query->result();
			$data['status'] = true;
			return $data;
		}
		else
		{
			$data['data'] = [];
			$data['status'] = false;
			return $data;
		}
	}



    // API 


    public function citylist()
    {
        
        $url_gambar = base_url().'assets/images/icon_kota/';
        $this->db->select('id, nama_kota, CONCAT("'.$url_gambar.'", icon) AS icon_kota', FALSE);
        $query = $this->db->get('jatra_city_table');
        return $query->result();
    }
	


    public function roomtype()
    {
        $query = $this->db->get('jatra_roomtype_table');
        return $query;
    }

}

/* End of file User_model.php */
/* Location: ./application/models/User_model.php */