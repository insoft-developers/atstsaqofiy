<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Common_model extends CI_Model {

	public function getdatahotel()
	{
		$query = $this->db->get('jatra_hotel_table');
		return $query;
	}

	public function getdatauser(){
		$this->db->where('status', 1);
		$query = $this->db->get('jatra_user_table');
		return $query;
	}

	public function gettypefasilitas()
	{
		$query = $this->db->get('jatra_type_table');
		return $query;
	}

	public function getfasilitasbyid($id_hotel, $type)
	{
		
		$this->db->where('id_hotel', $id_hotel);
		$this->db->where('type', $type);
		$query = $this->db->get('jatra_room_table');
		$data = $query->result();
		$HTML = "";

		if($query->num_rows() > 0)
		{
			foreach ($data as $key) 
			{
				$HTML .= '<option value="'.$key->id.'">'.$key->room_name.'</option>';
			}
		}
		else
		{	
			$HTML .= '<option value=""> - No Facilities - </option>';
		}
		

		

		return $HTML;
	}

	public function getfasilitasbyidfasilitas($id_fasilitas, $id_hotel, $type)
	{
		
		$this->db->where('id_hotel', $id_hotel);
		$this->db->where('type', $type);
		$query = $this->db->get('jatra_room_table');
		$data = $query->result();
		$HTML = "";

		if($query->num_rows() > 0)
		{
			foreach ($data as $key) 
			{
				
				$HTML .= '<option value = "'.$key->id.'"'; 
				if($id_fasilitas == $key->id)
				{
					$HTML .= 'selected>';
				}
				else
				{
					$HTML .= '>';	
				}

				$HTML.= $key->room_name.'</option>';

			}
		}
		else
		{	
			$HTML .= '<option value=""> - No Facilities - </option>';
		}

		return $HTML;
	}

}



/* End of file common_model.php */
/* Location: ./application/models/common_model.php */

