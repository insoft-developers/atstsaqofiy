<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Voucher Lists</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Voucher Lists</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
          <!-- Default box -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title"><button onclick="addData()" class="btn btn-success btn-sm">
                <i class="fas fa-plus"></i> Add Data
              </button></h3>
            <div class="card-tools">
              <button onclick="refreshData()" class="btn btn-primary btn-sm">
                <i class="fas fa-recycle"></i> Refresh
              </button>
            </div>
          </div>
          <div class="card-body">
              <table id="table_voucher" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th width="5%">ID</th>
                  <th width="*">Voucher</th>
                  <th width="10%">Image</th>
                  <th width="5%">Type</th>
                  <th width="10%">Hotel</th>
                  <th width="10%">Facility</th>
                  <th width="10%">Expired</th>
                  <th width="8%">Price</th>
                  <th width="10%">Created</th>
                  <th width="10%">Status</th>
                  <th width="10%">Action</th>
                </tr>
                </thead>
                <tbody></tbody>
              </table>
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->


    <div class="modal fade" id="modal-edit">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title"></h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
             <?php echo form_open_multipart('Promo/saveData', array('id'=> 'frmVoucher'));  ?>
                <input type="hidden" name="_method" id="_method" />
                <input type="hidden" id="id" name="id" />
                <div class="row">
                  <div class="col-md-12">
                      <div id="image_promo" style="margin-bottom: 10px;"></div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>Voucher Name :</label>
                      <input type="text" class="form-control" id="vouchername" name="vouchername" required>
                    </div>

                    <div class="form-group">
                      <label>Voucher Image :</label>
                      <input class="form-control" type="file" id="gambar" name="gambar">
                    </div>

                     <div class="form-group">
                      <label>Hotel Name :</label>
                      <select class="form-control" id="hotelname" name="hotelname" required>
                          <option value=""> - Pilih Hotel - </option>
                          <?php foreach ($hotel->result() as $key) {
                              echo '<option value="'.$key->id.'">'.$key->nama_hotel.' [ '.$key->kota.' ]</option>';
                          } ?>
                      </select>
                    </div>

                    <div class="form-group">
                      <label>Voucher For :</label>
                      <select class="form-control" id="vouchertype" name="vouchertype" required>
                          <option value=""> - Voucher Untuk - </option>
                          <?php foreach ($type->result() as $key) {
                              echo '<option value="'.$key->id.'">'.$key->jenis_fasilitas.'</option>';
                          } ?>
                      </select>
                    </div>

                    <div class="form-group">
                      <label>Facility :</label>
                      <select class="form-control" id="fasilitas" name="fasilitas" required>
                          <option value=""> - Pilih Fasilitas - </option>
                          
                      </select>
                    </div>

                   

                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>Voucher Price:</label>
                      <input type="number" class="form-control" id="voucherprice" name="voucherprice" required />
                    </div>
                    <div class="form-group">
                      <label>Expired Date :</label>
                      <input type="date" class="form-control" id="expireddate" name="expireddate" required>
                    </div>
                    <div class="form-group">
                      <label>Status :</label>
                      <select class="form-control" id="voucherstatus" name="voucherstatus" required>
                          <option value="1">Aktif</option>
                          <option value="0">NonAktif</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                        <label>Voucher Description:</label>
                        <textarea id="voucherdescription" name="voucherdescription" class="form-control" required></textarea>
                    </div>
                  </div>
                  
                </div>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
            <button style="display: none;" id="btn_tambah" type="submit" class="btn btn-primary btn-sm">Save changes</button>
            <button style="display: none;" id="btn_update" type="submit" class="btn btn-warning btn-sm">Update changes</button>
            <?php echo form_close();?>
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->


    <div class="modal fade" id="modal-hapus">
        <div class="modal-dialog">
          <div class="modal-content bg-danger">
            <div class="modal-header">
              <h4 class="modal-title">Konfirmasi Hapus Data</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <input type="hidden" id="id_hapus">
              <p>Anda yakin ingin mengahapus data ini...?</p>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-sm btn-outline-light" data-dismiss="modal">Close</button>
              <button onclick="deleteConfirm()" type="button" class="btn btn-sm btn-outline-light">Hapus Data</button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->


      <div class="modal fade" id="modal-image" data-backdrop="static">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title judul-modal-image"></h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
              <?php echo form_open_multipart('Hotel/saveSlider', array('id'=> 'frmImage'));  ?>
              <input type="hidden" id="id_hotel" name="id_hotel" />
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Hotel Image Slider :</label>
                    <input class="form-control" type="file" id="_slider" name="_slider" required>
                  </div>
                </div>
                <div class="col-md-6">
                    <button style="margin-top: 35px;" class="btn btn-sm btn-success">Add Image</button>
                </div>
              </div>
              
              <hr />
              <div id="table_image_slider"></div>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
            <?php echo form_close();?>
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->


  </div>
  <!-- /.content-wrapper -->


  <script>


  $("#voucherdescription").summernote();


  var Toast = Swal.mixin({
      toast: true,
      position: 'bottom-end',
      showConfirmButton: false,
      timer: 3000
  });


  function refreshData() {
     reloadTable();
  }


  $("#table_voucher").DataTable({
      "processing":true,
      "serverSide":true,
      "responsive": true,
      "order":[],
      "ajax":{
          url: "<?php echo base_url();?>index.php/Voucher/fetch_datatable",
          type:"POST"
      },
      "columnDefs":[
          {
              "targets":[0,10],
              "orderable":false,
          }
      ],
  });


  $("#vouchertype").change(function(){
      var id_hotel = $("#hotelname").val();
      var type = $(this).val();

      if(id_hotel == '') {
         alert("Nama Hotel Belum Dipilih....!");
      } 
      else {
         $.ajax({
            url : "<?php echo base_url() ;?>index.php/Voucher/getfasilitas",
            type : "POST",
            dataType : "JSON",
            data : {id_hotel:id_hotel, type:type},
            success : function(data) {
               console.log(data);
               $("#fasilitas").html("");
               $("#fasilitas").append(data);
            }
         })
      }

  })

  function addData() {
      $("#modal-edit").modal("show");
      $(".modal-title").text('Add Data');
      $("#btn_tambah").show();
      $("#btn_update").hide();
      resetForm();
      $("#_method").val("add");
      $("#gambar").attr("required", true);
  }



  function editData(id) {
    $("#modal-edit").modal("show");
    $(".modal-title").text('Edit Data');
    $("#btn_tambah").hide();
    $("#btn_update").show(); 
    $("#_method").val("edit");
    $("#gambar").removeAttr("required");

    $.ajax({
       url : "<?php echo base_url();?>index.php/Voucher/getdatabyid/"+id,
       type : "GET",
       dataType : "JSON",
       success : function(data) {
          console.log(data);
          $("#id").val(data.data[0].id);
          $("#vouchername").val(data.data[0].nama_voucher);
          $("#gambar").val("");
          $("#hotelname").val(data.data[0].id_hotel);
          $("#vouchertype").val(data.data[0].type_voucher);
          $("#expireddate").val(data.data[0].expired_date);
          $("#voucherprice").val(data.data[0].voucher_value);
          $("#voucherstatus").val(data.data[0].status);
          $("#voucherdescription").summernote("code", data.data[0].deskripsi);
          
          $("#image_promo").html('<img class="img-fluid" src="<?php echo base_url();?>assets/images/voucher/'+data.data[0].gambar+'">');

          getdatafasilitas(data.data[0].id_fasilitas, data.data[0].id_hotel, data.data[0].type_voucher);


       }
    })
      
  }


  function getdatafasilitas(id_fasilitas, id_hotel, type) {
      $.ajax({
         url : "<?php echo base_url();?>index.php/Voucher/getfasilitas",
         type : "POST",
         dataType : "JSON",
         data: {id_fasilitas:id_fasilitas, id_hotel:id_hotel, type:type},
         success: function(data) {
            console.log(data);
            $("#fasilitas").html("");
            $("#fasilitas").append(data);
         }
      })
  }


  $("#frmVoucher").submit(function(e){
      e.preventDefault();
      $("#loadingProgress").show();
      
      var url = "";
      var metode = $("#_method").val();
      if(metode == 'add') {
         url = "<?php echo base_url();?>index.php/Voucher/savedata";
      } else {
         url = "<?php echo base_url();?>index.php/Voucher/updatedata";
      }

      var file_data = $("#gambar").prop('files')[0];
      var form_data = new FormData($('#modal-edit form')[0]);

      form_data.append('file', file_data);
      $.ajax({
          url : url,
          dataType : "JSON",
          cache : false,
          contentType : false,
          processData : false,
          data : form_data,
          type : "POST",
          success : function(data) {
              $("#loadingProgress").hide();
              reloadTable();
              $("#modal-edit").modal('hide');
              console.log(data);
          }
      });
  });





  function deleteData(id) {
     $("#modal-hapus").modal("show");
     $("#id_hapus").val(id);
  }


  function deleteConfirm() {
     $("#loadingProgress").show();
     
     var id_hapus = $("#id_hapus").val();
     $.ajax({
        url : "<?php echo base_url();?>index.php/Voucher/deleteData",
        type : "POST",
        data : {id: id_hapus},
        success : function(data) {
              $("#loadingProgress").hide();
              Toast.fire({
                  icon: 'success',
                  title: ' Sukses Hapus Data'
              });
              reloadTable();
              $("#modal-hapus").modal("hide");
        },
        error: function() {
             alert('Hapus Data Gagal..!');
             $("#loadingProgress").hide();
             $("#modal-hapus").modal("hide");
        }
     })
  }

  $(document).ready(function(){

     $('#table_voucher').on('click', '#slide_image', function () {
          var id = $(this).attr("data-id");
          var nama_hotel = $(this).attr("data-hotel");
          $("#modal-image").modal("show");
          $(".judul-modal-image").text(nama_hotel);
          $("#id_hotel").val(id);
          show_table_image_slider(id);

      });

  });


  function show_table_image_slider(id) {
      $.ajax({
          url : "<?php echo base_url();?>index.php/Voucher/slider/"+id,
          type : "GET",
          dataType : "JSON",
          success : function(data) {
              $("#table_image_slider").html(data);
          }
      });
  }


  $("#frmImage").submit(function(e){
      e.preventDefault();
      $("#loadingProgress").show();
      var id_hotel = $("#id_hotel").val();
      var file_data = $("#_slider").prop('files')[0];
      var form_data = new FormData($('#modal-image form')[0]);
      form_data.append('file', file_data);
      $.ajax({
          url : "<?php echo base_url();?>index.php/Voucher/saveslider",
          dataType : "JSON",
          cache : false,
          contentType : false,
          processData : false,
          data : form_data,
          type : "POST",
          success : function(data) {
              $("#loadingProgress").hide();
              show_table_image_slider(id_hotel);
              $("#_slider").val("");
              
          }
      });
  });



  function deleteSlider(id, id_hotel) {
    var hapus = confirm("Apakah anda akan menghapus image slide ini...?");
    if(hapus == true) {
       hapusimageslider(id, id_hotel);
    }

  }  


  function hapusimageslider(id, id_hotel) {
     $.ajax({
        url :"<?php echo base_url();?>index.php/Voucher/hapusimageslider",
        type :"POST",
        dataType : "JSON",
        data : {id:id},
        success: function(data) {
           show_table_image_slider(id_hotel);
           Toast.fire({
                  icon: 'success',
                  title: ' Sukses Hapus Image Slider'
          });
        }

     })
  }
 
  
 



  function resetForm() {
     $("#vouchername").val("")
     $("#hotelname").val("");
     $("#vouchertype").val("");
     $("#gambar").val("");
     $("#fasilitas").html('<option value=""> - Pilih Fasilitas - </option>');
     $("#voucherprice").val("");
     $("#voucherstatus").val("1");
     $("#expireddate").val("");
     $("#image_promo").html("");
     $("#voucherdescription").summernote("code", "");
  }


  function reloadTable() {
    $("#table_voucher").DataTable().ajax.reload(null,false);
  }




</script>