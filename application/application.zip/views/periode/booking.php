<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Set Calender</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Set Calender</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
          <!-- Default box -->
        <div class="card">
          <div class="card-header">
            <?php 
                $bulan = $periode[0]->periode;
                if($bulan =='01') {
                   $bln = 'Januari';
                } else if($bulan=='02') {
                   $bln = 'Februari';
                } else if($bulan=='03') {
                   $bln = 'Maret';
                } else if($bulan=='04') {
                   $bln = 'April';
                }else if($bulan=='05') {
                   $bln = 'Mei';
                }else if($bulan=='06') {
                   $bln = 'Juni';
                }else if($bulan=='07') {
                   $bln = 'Juli';
                }else if($bulan=='08') {
                   $bln = 'Agustus';
                }else if($bulan=='09') {
                   $bln = 'September';
                }else if($bulan=='10') {
                   $bln = 'Oktober';
                }else if($bulan=='11') {
                   $bln = 'November';
                }else if($bulan=='12') {
                   $bln = 'Desember';
                }


            ?>
            <h3 class="card-title">Periode <?= $bln;?> <?= $periode[0]->tahun; ?> </h3>
            <div class="card-tools">
              <a href="<?= base_url();?>index.php/Periode"><button class="btn btn-warning btn-sm">
                <i class="fas fa-arrow-left"></i> Kembali
              </button></a>
            </div>
          </div>
          <div class="card-body" id="calenderisi">
             


          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->

 </div>
  <!-- /.content-wrapper -->
   


   


  <script>

  var showinput = false;
  var showprice = false;
  tampilkancalender();

  function tampilkancalender() {
      var period = "<?= $this->uri->segment('3');?>"
      $.ajax({
         url : "<?php echo base_url();?>index.php/Booking/tampilkancalender",
         type : "POST",
         dataType : "JSON",
         data : {period:period},
         success: function(data) {
            $("#calenderisi").html(data);
         }
      })
  }


  $("#roomtype").select2();

  var Toast = Swal.mixin({
      toast: true,
      position: 'bottom-end',
      showConfirmButton: false,
      timer: 3000
  });


  function availdata(id) {
     if(showinput == false) {
        $("#avail_input_"+id).show();
        $("#avail_id_"+id).hide();
         $("#avail_input_"+id).focus();
        showinput = true; 
     }else{
        var availvalue = $("#avail_input_"+id).val();
        if(availvalue == '') {
            alert('availability tidak boleh kosong...!');
        }
        else {
            $("#avail_input_"+id).hide();
            $("#avail_id_"+id).show();
            
            showinput = false;

            $.ajax({
                url : "<?php echo base_url();?>index.php/Booking/updateavail",
                type : "POST",
                dataType : "JSON",
                data : {id:id, nilai:availvalue},
                success :function(data){
                    $("#avail_id_"+id).text(availvalue);        
                }
            });
        }
        
     }
     
  }


  function pricedata(id) {
     if(showprice == false) {
        $("#price_input_"+id).show();
        $("#price_id_"+id).hide();
        $("#price_input_"+id).focus();
        showprice = true; 
     }else{
        var pricevalue = $("#price_input_"+id).val();
        if(pricevalue == '') {
             alert('price tidak boleh kosong...!');
        } else {
            $("#price_input_"+id).hide();
            $("#price_id_"+id).show();
            
            showprice = false;

            $.ajax({
                url : "<?php echo base_url();?>index.php/Booking/updateprice",
                type : "POST",
                dataType : "JSON",
                data : {id:id, nilai:pricevalue},
                success :function(data){
                    $("#price_id_"+id).text(pricevalue);        
                }
            });
        }        
     }
     
  }


  
  


  




  function reloadTable() {
    $("#table_city").DataTable().ajax.reload(null,false);
  }




</script>