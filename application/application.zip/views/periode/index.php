<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Set Periode Booking</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Set Periode Booking</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
          <!-- Default box -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title"><button onclick="addData()" class="btn btn-success btn-sm">
                <i class="fas fa-plus"></i> Add Data
              </button></h3>
            <div class="card-tools">
              <button onclick="refreshData()" class="btn btn-primary btn-sm">
                <i class="fas fa-recycle"></i> Refresh
              </button>
            </div>
          </div>
          <div class="card-body">
              <table id="table_city" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th width="5%">ID</th>
                  <th width="*">Nama Periode</th>
                  <th width="25%">Room</th>
                  <th width="20%">Action</th>
                </tr>
                </thead>
                <tbody></tbody>
              </table>
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->


    <div class="modal fade" id="modal-edit">
      <div class="modal-dialog modal-sm">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title"></h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
             <?php echo form_open_multipart('Periode/saveData', array('id'=> 'frmPeriode'));  ?>
                <input type="hidden" name="_method" id="_method" />
                <input type="hidden" id="id" name="id" />
                <div class="form-group">
                  <label>Periode :</label>
                  <select id="periode" name="periode" class="form-control" required>
                      <option value=""> - Pilih Periode - </option>
                      <option value="01">Januari</option>
                      <option value="02">Februari</option>
                      <option value="03">Maret</option>
                      <option value="04">April</option>
                      <option value="05">Mei</option>
                      <option value="06">Juni</option>
                      <option value="07">Juli</option>
                      <option value="08">Agustus</option>
                      <option value="09">September</option>
                      <option value="10">Oktober</option>
                      <option value="11">November</option>
                      <option value="12">Desember</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Tahun :</label>
                  <select id="tahun" name="tahun" class="form-control" required>
                      <option value=""> - Pilih Tahun - </option>
                      <option value="<?= date('Y');?>"><?= date('Y');?></option>
                      <option value="<?= date('Y') + 1;?>"><?= date('Y') + 1;?></option>
                      <option value="<?= date('Y') + 2;?>"><?= date('Y') + 2;?></option>
                      <option value="<?= date('Y') + 3;?>"><?= date('Y') + 3;?></option>
                      <option value="<?= date('Y') + 4;?>"><?= date('Y') + 4;?></option>
                  </select>
                </div>
                <div class="form-group">
                    <label>Type Kamar :</label>
                    <select id="roomtype" name="roomtype[]" class="form-control" multiple="multiple" required>
                       <?php foreach ($roomtype->result() as $key ) {
                            echo '<option value="'.$key->id.'">'.$key->room_name.'</option>';
                       }?>
                    </select>
                </div>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
            <button style="display: none;" id="btn_tambah" type="submit" class="btn btn-primary btn-sm">Save changes</button>
            <button style="display: none;" id="btn_update" type="submit" class="btn btn-warning btn-sm">Update changes</button>
            <?php echo form_close();?>
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->



    <div class="modal fade" id="modal-hapus">
        <div class="modal-dialog">
          <div class="modal-content bg-danger">
            <div class="modal-header">
              <h4 class="modal-title">Konfirmasi Hapus Data</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <input type="hidden" id="id_hapus">
              <p>Anda yakin ingin mengahapus data ini...?</p>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-sm btn-outline-light" data-dismiss="modal">Close</button>
              <button onclick="deleteConfirm()" type="button" class="btn btn-sm btn-outline-light">Hapus Data</button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->
  </div>
  <!-- /.content-wrapper -->


  <script>


  $("#roomtype").select2();

  var Toast = Swal.mixin({
      toast: true,
      position: 'bottom-end',
      showConfirmButton: false,
      timer: 3000
  });


  function refreshData() {
     reloadTable();
  }



  $("#table_city").DataTable({
      "processing":true,
      "serverSide":true,
      "responsive": true,
      "order":[],
      "ajax":{
          url: "<?php echo base_url();?>index.php/Periode/fetch_datatable",
          type:"POST"
      },
      "columnDefs":[
          {
              "targets":[0],
              "orderable":false,
          }
      ],
  });

  


  function addData() {
      $("#modal-edit").modal("show");
      $(".modal-title").text('Add Data');
      $("#btn_tambah").show();
      $("#btn_update").hide();
      resetForm();
      $("#_method").val("add");
      $("#gambar").attr("required", true);
  }



  function editData(id) {
    $("#modal-edit").modal("show");
    $(".modal-title").text('Edit Data');
    $("#btn_tambah").hide();
    $("#btn_update").show(); 
    $("#_method").val("edit");
    $("#gambar").removeAttr("required");

    $.ajax({
       url : "<?php echo base_url();?>index.php/Periode/getdatabyid/"+id,
       type : "GET",
       dataType : "JSON",
       success : function(data) {
          console.log(data);
          $("#id").val(data.data[0].id);
          $("#cityname").val(data.data[0].nama_kota);
          $("#gambar").val("");


       }
    })
      
  }



  $("#frmPeriode").submit(function(e){
      e.preventDefault();
      $("#loadingProgress").show();
      
      var url = "";
      var metode = $("#_method").val();
      if(metode == 'add') {
         url = "<?php echo base_url();?>index.php/Periode/savedata";
      } else {
         url = "<?php echo base_url();?>index.php/Periode/updatedata";
      }

      $.ajax({
          url : url,
          dataType : "JSON",
          data : $("#frmPeriode").serialize(),
          type : "POST",
          success : function(data) {
              $("#loadingProgress").hide();
              reloadTable();
              $("#modal-edit").modal('hide');
              console.log(data);
          }
      });
  });


  function deleteData(id) {
     $("#modal-hapus").modal("show");
     $("#id_hapus").val(id);
  }


  function deleteConfirm() {
     $("#loadingProgress").show();
     
     var id_hapus = $("#id_hapus").val();
     $.ajax({
        url : "<?php echo base_url();?>index.php/Periode/deleteData",
        type : "POST",
        data : {id: id_hapus},
        success : function(data) {
              $("#loadingProgress").hide();
              Toast.fire({
                  icon: 'success',
                  title: ' Sukses Hapus Data'
              });
              reloadTable();
              $("#modal-hapus").modal("hide");
        }
     })
  }


  function resetForm() {
     $("#cityname").val("");
     $("#gambar").val("");
  }


  function reloadTable() {
    $("#table_city").DataTable().ajax.reload(null,false);
  }




</script>