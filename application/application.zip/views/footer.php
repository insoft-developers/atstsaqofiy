<!-- /.content-wrapper -->
  <footer class="main-footer">
    <div id="loadingProgress" style="display:none;">
        <img src="<?php echo base_url();?>assets/images/ajax-loader.gif" class="ajax-loader">
    </div>
    <strong>Copyright &copy; 2021 <a href="<?php echo base_url();?>">Jatra Hotels & Resorts</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0.0
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->


<!-- AdminLTE App -->
<script src="<?php echo base_url();?>assets/dist/js/adminlte.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url();?>assets/dist/js/demo.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo base_url();?>assets/dist/js/pages/dashboard.js"></script>

</body>
</html>
