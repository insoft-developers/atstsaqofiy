<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Hotel Lists</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Hotel Lists</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
          <!-- Default box -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title"><button onclick="addData()" class="btn btn-success btn-sm">
                <i class="fas fa-plus"></i> Add Data
              </button></h3>
            <div class="card-tools">
              <button onclick="refreshData()" class="btn btn-primary btn-sm">
                <i class="fas fa-recycle"></i> Refresh
              </button>
            </div>
          </div>
          <div class="card-body">
              <table id="table_hotel" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th width="5%">ID</th>
                  <th width="*">Hotel Name</th>
                  <th width="20%">Hotel City</th>
                  <th width="20%">Hotel Icon</th>
                  <th width="20%">Slide Image</th>
                  <th width="15%">Action</th>
                </tr>
                </thead>
                <tbody></tbody>
              </table>
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->


    <div class="modal fade" id="modal-edit">
      <div class="modal-dialog modal-sm">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title"></h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
             <?php echo form_open_multipart('Hotel/saveData', array('id'=> 'frmHotel'));  ?>
                <input type="hidden" name="_method" id="_method" />
                <input type="hidden" id="id" name="id" />
                <div class="form-group">
                  <label>Hotel Name :</label>
                  <input type="text" class="form-control" id="hotelname" name="hotelname" required>
                </div>
                <div class="form-group">
                  <label>Hotel City :</label>
                  <select class="form-control" id="hotelcity" name="hotelcity" required>
                    <option value=""> - Pilih Kota - </option>
                    <option value="Balikpapan">Balikpapan</option>
                    <option value="Pekanbaru">Pekanbaru</option>
                    <option value="Bali">Bali</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Hotel Icon :</label>
                  <input type="file" id="gambar" name="gambar" id="gambar">
                </div>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
            <button style="display: none;" id="btn_tambah" type="submit" class="btn btn-primary btn-sm">Save changes</button>
            <button style="display: none;" id="btn_update" type="submit" class="btn btn-warning btn-sm">Update changes</button>
            <?php echo form_close();?>
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->


    <div class="modal fade" id="modal-hapus">
        <div class="modal-dialog">
          <div class="modal-content bg-danger">
            <div class="modal-header">
              <h4 class="modal-title">Konfirmasi Hapus Data</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <input type="hidden" id="id_hapus">
              <p>Anda yakin ingin mengahapus data ini...?</p>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-sm btn-outline-light" data-dismiss="modal">Close</button>
              <button onclick="deleteConfirm()" type="button" class="btn btn-sm btn-outline-light">Hapus Data</button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->


      <div class="modal fade" id="modal-image" data-backdrop="static">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title judul-modal-image"></h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
              <?php echo form_open_multipart('Hotel/saveSlider', array('id'=> 'frmImage'));  ?>
              <input type="hidden" id="id_hotel" name="id_hotel" />
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Hotel Image Slider :</label>
                    <input class="form-control" type="file" id="_slider" name="_slider" required>
                  </div>
                </div>
                <div class="col-md-6">
                    <button style="margin-top: 35px;" class="btn btn-sm btn-success">Add Image</button>
                </div>
              </div>
              
              <hr />
              <div id="table_image_slider"></div>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
            <?php echo form_close();?>
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->


  </div>
  <!-- /.content-wrapper -->


  <script>

  var Toast = Swal.mixin({
      toast: true,
      position: 'bottom-end',
      showConfirmButton: false,
      timer: 3000
  });


  function refreshData() {
     reloadTable();
  }


  $("#table_hotel").DataTable({
      "processing":true,
      "serverSide":true,
      "responsive": true,
      "order":[],
      "ajax":{
          url: "<?php echo base_url();?>index.php/Hotel/fetch_datatable",
          type:"POST"
      },
      "columnDefs":[
          {
              "targets":[4],
              "orderable":false,
          }
      ],
  });


  

  function addData() {
      $("#modal-edit").modal("show");
      $(".modal-title").text('Add Data');
      $("#btn_tambah").show();
      $("#btn_update").hide();
      resetForm();
      $("#_method").val("add");
      $("#gambar").attr("required", true);
  }



  function editData(id) {
    $("#modal-edit").modal("show");
    $(".modal-title").text('Edit Data');
    $("#btn_tambah").hide();
    $("#btn_update").show(); 
    $("#_method").val("edit");
    $("#gambar").removeAttr("required");

    $.ajax({
       url : "<?php echo base_url();?>index.php/Hotel/getdatabyid/"+id,
       type : "GET",
       dataType : "JSON",
       success : function(data) {
          console.log(data);
          $("#id").val(data.data[0].id);
          $("#hotelname").val(data.data[0].nama_hotel);
          $("#hotelcity").val(data.data[0].kota);
          $("#gambar").val("");


       }
    })
      
  }


  $("#frmHotel").submit(function(e){
      e.preventDefault();
      $("#loadingProgress").show();
      
      var url = "";
      var metode = $("#_method").val();
      if(metode == 'add') {
         url = "<?php echo base_url();?>index.php/Hotel/savedata";
      } else {
         url = "<?php echo base_url();?>index.php/Hotel/updatedata";
      }

      var file_data = $("#gambar").prop('files')[0];
      var form_data = new FormData($('#modal-edit form')[0]);

      form_data.append('file', file_data);
      $.ajax({
          url : url,
          dataType : "JSON",
          cache : false,
          contentType : false,
          processData : false,
          data : form_data,
          type : "POST",
          success : function(data) {
              $("#loadingProgress").hide();
              reloadTable();
              $("#modal-edit").modal('hide');
              console.log(data);
          }
      });
  });





  function deleteData(id) {
     $("#modal-hapus").modal("show");
     $("#id_hapus").val(id);
  }


  function deleteConfirm() {
     $("#loadingProgress").show();
     
     var id_hapus = $("#id_hapus").val();
     $.ajax({
        url : "<?php echo base_url();?>index.php/Hotel/deleteData",
        type : "POST",
        data : {id: id_hapus},
        success : function(data) {
              $("#loadingProgress").hide();
              Toast.fire({
                  icon: 'success',
                  title: ' Sukses Hapus Data'
              });
              reloadTable();
              $("#modal-hapus").modal("hide");
        },
        error: function() {
             alert('Hapus Data Gagal..!');
             $("#loadingProgress").hide();
             $("#modal-hapus").modal("hide");
        }
     })
  }

  $(document).ready(function(){

     $('#table_hotel').on('click', '#slide_image', function () {
          var id = $(this).attr("data-id");
          var nama_hotel = $(this).attr("data-hotel");
          $("#modal-image").modal("show");
          $(".judul-modal-image").text(nama_hotel);
          $("#id_hotel").val(id);
          show_table_image_slider(id);

      });

  });


  function show_table_image_slider(id) {
      $.ajax({
          url : "<?php echo base_url();?>index.php/Hotel/slider/"+id,
          type : "GET",
          dataType : "JSON",
          success : function(data) {
              $("#table_image_slider").html(data);
          }
      });
  }


  $("#frmImage").submit(function(e){
      e.preventDefault();
      $("#loadingProgress").show();
      var id_hotel = $("#id_hotel").val();
      var file_data = $("#_slider").prop('files')[0];
      var form_data = new FormData($('#modal-image form')[0]);
      form_data.append('file', file_data);
      $.ajax({
          url : "<?php echo base_url();?>index.php/Hotel/saveslider",
          dataType : "JSON",
          cache : false,
          contentType : false,
          processData : false,
          data : form_data,
          type : "POST",
          success : function(data) {
              $("#loadingProgress").hide();
              show_table_image_slider(id_hotel);
              $("#_slider").val("");
              
          }
      });
  });



  function deleteSlider(id, id_hotel) {
    var hapus = confirm("Apakah anda akan menghapus image slide ini...?");
    if(hapus == true) {
       hapusimageslider(id, id_hotel);
    }

  }  


  function hapusimageslider(id, id_hotel) {
     $.ajax({
        url :"<?php echo base_url();?>index.php/Hotel/hapusimageslider",
        type :"POST",
        dataType : "JSON",
        data : {id:id},
        success: function(data) {
           show_table_image_slider(id_hotel);
           Toast.fire({
                  icon: 'success',
                  title: ' Sukses Hapus Image Slider'
          });
        }

     })
  }
 
  
 



  function resetForm() {
     $("#hotelname").val("");
     $("#hotelcity").val("");
     $("#gambar").val("");
  }


  function reloadTable() {
    $("#table_hotel").DataTable().ajax.reload(null,false);
  }




</script>