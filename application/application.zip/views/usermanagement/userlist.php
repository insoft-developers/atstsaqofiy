<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>User Lists</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>">Dashboard</a></li>
              <li class="breadcrumb-item active">User Lists</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
          <!-- Default box -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Edit and Delete User List Data Here</h3>
            <div class="card-tools">
              <button onclick="refreshData()" class="btn btn-primary btn-sm">
                <i class="fas fa-recycle"></i> Refresh
              </button>
            </div>
          </div>
          <div class="card-body">
              <table id="table_users" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Name</th>
                  <th>Status</th>
                  <th>Date</th>
                  <th>Unit Owner</th>
                  <th>Poin</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody></tbody>
              </table>
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->


    <div class="modal fade" id="modal-edit">
      <div class="modal-dialog modal-sm">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Edit Data</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
             <?php echo form_open('Users/updateData', array('id'=> 'frmUser'));  ?>
                <input type="hidden" id="id" name="id" />
                <input type="hidden" id="poin" name="poin">
                <div class="form-group">
                  <label>Username :</label>
                  <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="form-group">
                  <label>Email :</label>
                  <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="form-group">
                  <label>Password :</label>
                  <input type="password" class="form-control" id="password" name="password">
                </div>
                <div class="form-group">
                  <label>Full Name :</label>
                  <input type="text" class="form-control" id="fullname" name="fullname" required>
                </div>
                <div class="form-group">
                  <label>Status :</label>
                  <select class="form-control" id="status" name="status" required>
                    <option value=""> - Pilih Status - </option>
                    <option value="1">Aktif</option>
                    <option value="0">NonAktif</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Unit Owner:</label>
                  <select class="form-control" id="unitowner" name="unitowner" required>
                      <option value=""> - Pilih Unit Owner - </option>
                      <option value="0"> No Unit Owner </option>
                      <option value="1"> Type 1 (Bronze) </option>
                      <option value="2"> Type 2 (Silver) </option>
                      <option value="3"> Type 3 (Gold) </option>
                      <option value="4"> Type 4 (Platinum) </option>
                  </select>

                </div>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-warning btn-sm">Update changes</button>
            <?php echo form_close();?>
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->


    <div class="modal fade" id="modal-hapus">
        <div class="modal-dialog">
          <div class="modal-content bg-danger">
            <div class="modal-header">
              <h4 class="modal-title">Konfirmasi Hapus Data</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <input type="hidden" id="id_hapus">
              <p>Anda yakin ingin mengahapus data ini...?</p>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-sm btn-outline-light" data-dismiss="modal">Close</button>
              <button onclick="deleteConfirm()" type="button" class="btn btn-sm btn-outline-light">Hapus Data</button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->



  </div>
  <!-- /.content-wrapper -->


  <script>

  var Toast = Swal.mixin({
      toast: true,
      position: 'bottom-end',
      showConfirmButton: false,
      timer: 3000
  });


  function refreshData() {
     reloadTable();
  }


  $("#table_users").DataTable({
      "processing":true,
      "serverSide":true,
      "responsive": true,
      "order":[],
      "ajax":{
          url: "<?php echo base_url();?>index.php/Users/fetch_datatable",
          type:"POST"
      },
      "columnDefs":[
          {
              "targets":[6],
              "orderable":false,
          }
      ],
  });


  function editData(id) {
    $("#modal-edit").modal("show");
    $.ajax({
       url : "<?php echo base_url();?>index.php/Users/getdatabyid/"+id,
       type : "GET",
       dataType : "JSON",
       success : function(data) {
          console.log(data);
          $("#id").val(data.data[0].id);
          $("#username").val(data.data[0].username);
          $("#email").val(data.data[0].email);
          $("#fullname").val(data.data[0].fullname);
          $("#status").val(data.data[0].status);
          $("#password").val("");
          $("#unitowner").val(data.data[0].unit_owner);
          $("#poin").val(data.data[0].poin);
       }
    })
      
  }


  $("#frmUser").submit(function(e){
      e.preventDefault();
      $("#loadingProgress").show();
      $.ajax({
         url : "<?php echo base_url();?>index.php/Users/updateData",
         type : "POST",
         data : $("#frmUser").serialize(),
         success : function(data) {
              $("#loadingProgress").hide();
              Toast.fire({
                  icon: 'success',
                  title: ' Sukses Update Data'
              });
              reloadTable();
              $("#modal-edit").modal("hide");
         }
      })

  });


  function deleteData(id) {
     $("#modal-hapus").modal("show");
     $("#id_hapus").val(id);
  }


  function deleteConfirm() {
     $("#loadingProgress").show();
     var id_hapus = $("#id_hapus").val();
     $.ajax({
        url : "<?php echo base_url();?>index.php/Users/deleteData",
        type : "POST",
        data : {id: id_hapus},
        success : function(data) {
              $("#loadingProgress").hide();
              Toast.fire({
                  icon: 'success',
                  title: ' Sukses Hapus Data'
              });
              reloadTable();
              $("#modal-hapus").modal("hide");
        }
     })
  }


  function reloadTable() {
    $("#table_users").DataTable().ajax.reload(null,false);
  }




</script>